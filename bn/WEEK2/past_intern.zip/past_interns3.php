<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en">

<head>
 <link rel="shortcut icon" href="images/head.png" />
  <title>B N Satnalika Foundation</title>
  <meta name="description" content="scholarships to poor children and collect funds" />
  <meta name="keywords" content="scholarship babulal nagarmal satnalika foundation  education poor children" />
  <meta http-equiv="content-type" content="text/html; charset=utf-8" />
  <meta name="author" content="veer chandra" />
  <link rel="stylesheet" type="text/css" href="css/style1.css" />
  <script type="text/javascript" src="js/jquery.min.js"></script>
  <script type="text/javascript" src="js/jquery.easing.min.js"></script>
  <script type="text/javascript" src="js/jquery.lavalamp.min.js"></script>
  <script type="text/javascript">
    $(function() {
      $("#lava_menu").lavaLamp({
        fx: "backout",
        speed: 700
      });
    });
  </script>
    <script type="text/javascript" src="js/jquery.nivo.slider.pack.js"></script>
    <script type="text/javascript">
    $(window).load(function() {
        $('#slider').nivoSlider();
    });

    </script>

</head>

<body>

  <div id="main">	
	<br>
	<!-- <div id="header"> 
        <div id="header_name"> 	  
          <h1>  Babulal Nagarmal Satnalika <span>Foundation</span></h1>
        </div><!--close header_name-->	
	<!--		<div id="header_slogan"> 		
	      <h2>Promoting education..</h2>
		 </div><!--close header_slogan-->	
		  
    <!--  </div><!--close header-->
    <div id="footer">
 <div>	
    <h4 style="margin-left:200px;margin-top:-45px;font: normal 105% verdana;"><a href="md.php">Mandatory Disclosure</a>&nbsp | &nbsp<a href="shop.php">Shop</a>&nbsp | &nbsp<a href="http://games.bnsatnalikafoundation.org">Games</a>&nbsp | &nbsp<a href="advertise.php">Advertise With Us</a>&nbsp | &nbsp<a href="contactus.php">Contact us</a>&nbsp | &nbsp <a href="newsletter.php">BNMS Foundation Newsletter</a> &nbsp | &nbsp <a href="http://webmail.bnsatnalikafoundation.org">Webmail</a>&nbsp | &nbsp<a href="comment.php">Comment</a>&nbsp | &nbsp<a href="poll.php">Polls</a>&nbsp | &nbsp<a href="./phpBB3/index.php" target="_blank">Forum</a>&nbsp</h4>
    </div>
	<div style="position:relative;left:833px">
		<form method="get" action="http://www.google.com/search">

<div style="border:1px solid black;padding:4px;width:20em;">
<table border="0" cellpadding="0">
<tr><td>
<input type="text"   name="q" size="25"
 maxlength="255" value="" placeholder="Enter a keyword to search"/>
<input type="submit" value="Search" /></td></tr>
<tr><td align="center" style="font-size:75%">
<input type="checkbox"  name="sitesearch"
 value="bnsatnalikafoundation.org" checked /> only search BN Satnalika Foundation Site<br />
</td></tr></table>
</div>

</form>
</div>
	</div>
	 <center> <img style="margin-top:-25px;" src="../images/header1.png" width="1000" height="100" margin="0px" usemap="#map"/> 
				<map name="map">
					<area shape="rect" coords="0,0,150,100" href="index.php" />
				</map>
	 </center>
	<div id="content_main">
		<div style="margin-top:-0px;" id="menubar">
		  <ul class="lavaLampWithImage" id="lava_menu">
			<li><a href="index.php">Home</a></li>
			<li><a href="aboutus.php">About Us</a></li>
			<li><a href="gallery.php">Gallery</a></li>
			<li><a href="apply.php">Apply</a></li>
			<li><a href="volunteer.php">Volunteer</a></li>
			<li><a href="supportus.php">Support Us</a></li>
			<li class = "current"><a href="past_intern.php">Past Interns</a></li>
			<li><a href="feedback.php">Feedback</a></li>
			<li><a href="contactus.php">Contact Us</a></li>
		  </ul>
		</div><!--close menubar-->	    
		<div id="site_content">        	  
	 <div id="banner_image">
	    <div id="slider-wrapper">        
          <div id="slider" class="nivoSlider">
            <img style="height:250px;width:960px;" src="images/banner.jpg" alt=""/>
            <img style="height:250px;width:960px;" src="images/banner1.jpg" alt="" />
            <img style="height:250px;width:960px;" src="images/banner2.jpg" alt="" />
			<img style="height:250px;width:960px;" src="images/banner3.jpg" alt="" />
			<img style="height:250px;width:960px;" src="images/banner4.jpg" alt="" />
			<img style="height:250px;width:960px;" src="images/6.jpg" alt="" />
			<img style="height:250px;width:960px;" src="images/7.jpg" alt="" />
			<img style="height:250px;width:960px;" src="images/8.jpg" alt="" />
			<img style="height:250px;width:960px;" src="images/3 copy.jpg" alt="" />
			<img style="height:250px;width:960px;" src="images/5 copy.jpg" alt="" />
			<a herf="http://shopoffice.in/"><img style="height:250px;width:960px;" src="images/9.jpg" alt="" /></a>
		  </div>
		</div><!--close slider-wrapper-->
	  </div><!--close banner_image-->		
</br>
<div class = "b">
<h1 style="margin-left:0px;">Past Interns</h1>
<hr>
</br>
<div class="jj" style="height:135px;width:145px;">
<img id="i" src = "images/pic1.png" height="125" width= "125"></br>
<div  style="margin-top:1px;">Snehasis Saha</div>
</div>
<p style='width:500px;margin-top:-130px;margin-left:170px;font-size:12px;text-align: justify;'>Snehasis is currently pursuing B.Tech degree from VIT University. Interested<br>in programming, web development. Education is a necessity in human lives.</br></br>
<a href="http://in.linkedin.com/pub/snehasis-saha/35/a93/224"><img src="images/linkedin.png" height="30" width="30"/></a> &nbsp; 
<a href="mailto:snehasis_davids419@yahoo.in"><img src="images/mail.png" height="30" width="30"/></a>&nbsp;
</br></br>
<hr style="background-color:brown;height:2px;margin-top:40px"></br>
</div>

<h4 style="margin-left:350px;margin-top:-25px;text-align:justify; "><a href="past_interns2.php"><< Previous</a></h4>
<!--<div class="w" style="text-align:justify;">-->

<div style="overflow:hidden;height:130px;margin-top:50px;margin-left:270px;"><form action="http://www.flipkart.com/search-all" method="get"><div style="background: #09334d; padding: 5px; float: center;height:80px;width:650px;"><img alt="Flipkart.com" title="Flipkart.com" style="max-width: 150px;vertical-align:middle;margin-left:70px;margin-top:20px;" src="http://www.flipkart.com/images/flipkart_india.png" /><input type="hidden" name="affid" value="bnsatnalik" /><input type="hidden" name="wgtid" value="FK-AF-SB" /><input style="margin-top:25px;" type="text" name="query" /><select onchange = 'this.form.action="http://www.flipkart.com/search-"+this.value;'><option value='all' selected>All Categories</option><option value='clothing' >Clothing</option><option value='footwear' >Footwear</option><option value='mobiles' >Mobiles & Accessories</option><option value='computers' >Computers</option><option value='leather-travel' >Watches, Bags & Wallets</option><option value='cameras' >Cameras</option><option value='books-stationeries' >Books, Pens & Stationery</option><option value='homeappliance' >Home & Kitchen</option><option value='health-and-beauty' >Beauty & Personal Care</option><option value='games' >Games & Consoles</option><option value='tv-video' >TVs & Video Players</option><option value='audioplayers' >Home Audio & MP3 Players</option><option value='movies-music' >Music, Movies & Posters</option><option value='babycaretoys' >Baby Care & Toys</option><option value='sports-fitness' >Sport & Fitness</option><option value='ebooks' >eBooks</option></select><input type="button" onclick="this.form.submit()" value="Search" /></div></form></div>


<div class="sidebar_containerjd1" style="margin-top:-600px"> 
			 <br style="clear:both;" />
			 <br>
			 
			  <div class="sidebar">
				<div class="sidebar_item">
				<br/>
					<h2><u>We Believe</u></h2>
				<!--    <h4>August 2012</h4> -->
					<p><i>"Purpose of education is not to fill the minds of students with facts rather it is to teach them to think." says Vice Chairman BNMS Foundation.
						</i></p>
					<a href="https://www.facebook.com/BNSATNALIKAFOUNDATION">Read more</a>
				  </div><!--close sidebar_item--> 
			  </div><!--close sidebar-->     		
			  
			  <div class="sidebar">
				<div class="sidebar_item">		   
					<p><i>"Education with values given to our society, is the best remedy to all societal evils."</i></p>
					<a href="https://www.facebook.com/BNSATNALIKAFOUNDATION">Read more</a>
				</div><!--close sidebar_item--> 
			  </div><!--close sidebar--> 
			   <div class="sidebar">
				<div class="sidebar_item">
			   
					<p><i>"Education is simply the soul of a society as it passes from one generation to another. " </i></p>
					<a href="https://www.facebook.com/BNSATNALIKAFOUNDATION">Read more</a>
				</div><!--close sidebar_item--> 
			  </div><!--close sidebar--> 
			   <br style="clear:both;" />
			   
				<div class="sidebar_fb">
					<br>  
					<center><b>Follow us on Twitter</b></center><hr>
					<center>  <a href="https://twitter.com/BNMSFoundation" class="twitter-follow-button" data-show-count="false" data-lang="en" data-size="small">Follow @twitterapi</a>
								<script>!function(d,s,id){var js,fjs=d.getElementsByTagName(s)[0];if(!d.getElementById(id)){js=d.createElement(s);js.id=id;js.src="//platform.twitter.com/widgets.js";fjs.parentNode.insertBefore(js,fjs);}}(document,"script","twitter-wjs");</script>
							
					</center><br>
					<center><b>Follow us on Linkedin</b></center><hr>
					<center>
					
					<script src="//platform.linkedin.com/in.js" type="text/javascript"></script><script type="IN/FollowCompany" data-id="2770929" data-counter="right"></script>
					</center>
					<br>
					<center><b>Join us on Facebook </b></center><hr>
					<center><iframe src="https://www.facebook.com/plugins/like.php?href=https://www.facebook.com/BNSATNALIKAFOUNDATION"
					scrolling="no" frameborder="0"
					style="border:none; width:205px; height:66px"></iframe>	</center>
					<br>
					<center><b>Tell your friend</b></center><hr>
					<center>
					<!-- SMARTADDON BEGIN -->
					<script type="text/javascript">
					(function() {
					var s=document.createElement('script');s.type='text/javascript';s.async = true;
					s.src='http://s1.smartaddon.com/share_addon.js';
					var j =document.getElementsByTagName('script')[0];j.parentNode.insertBefore(s,j);
					})();
					</script>
					<a href="http://www.smartaddon.com/?share" title="Tell a Friend" onclick="return sa_tellafriend('','email')"><img alt="Tell a Friend" src="http://dl.dropbox.com/u/18603960/tellafriend.png" width="210" height="60" border="0" /></a>
					<!-- SMARTADDON END -->
					</center>
				</div><!--close sidebar_fb-->	
					
			</div><!--close sidebar_container-->	
		   <br style="clear:both;" />
		  </div><!--close content-->	
		</div><!--close site_content-->	
	</div>
    <div id="footer">   
	  <div id="footer_content">
	  <!-- Counter Code START -->
	 <!--<u>Visitor's Count:</u><br />-->
	<div align='center'><a href='http://www.hit-counts.com'><img src='http://www.hit-counts.com/counter.php?t=3&digits=6&ic=0&cid=1149589' border='0' alt='Visitor Counter'></a><BR>Best View in Google Chrome </div>
Copyright &copy 2012 BNMS Foundation | All rights reseved | <a href="terms.php">Terms & Conditions</a> | <a href="sitemap.html">Site Map</a> | Developed by <a href="https://www.facebook.com/veer.cg">Veer Chandra</a>
     <br /> <br style="clear:both;" />
	  </div><!--close footer_content-->	
    </div><!--close footer-->	
  </div><!--close main-->	
  <!--Start of Zopim Live Chat Script-->
<script type="text/javascript">
window.$zopim||(function(d,s){var z=$zopim=function(c){z._.push(c)},$=z.s=
d.createElement(s),e=d.getElementsByTagName(s)[0];z.set=function(o){z.set.
_.push(o)};z._=[];z.set._=[];$.async=!0;$.setAttribute('charset','utf-8');
$.src='//cdn.zopim.com/?1CGLD5bhI75qkW4rQ59d2OSKtumeOUqd';z.t=+new Date;$.
type='text/javascript';e.parentNode.insertBefore($,e)})(document,'script');
</script>
<!--End of Zopim Live Chat Script-->
<script type="text/javascript">$zopim(function() {
// Insert API calls below this line
// e.g. $zopim.livechat.setLanguage('en');
// Insert API calls above this line
})
</script>
<script id="_webengage_script_tag" type="text/javascript">
  window.webengageWidgetInit = window.webengageWidgetInit || function(){
    webengage.init({
      licenseCode:"~2024bc00"
    }).onReady(function(){
      webengage.render();
    });
  };
  (function(d){
    var _we = d.createElement('script');
    _we.type = 'text/javascript';
    _we.async = true;
    _we.src = (d.location.protocol == 'https:' ? "//ssl.widgets.webengage.com" : "//cdn.widgets.webengage.com") + "/js/widget/webengage-min-v-3.0.js";
    var _sNode = d.getElementById('_webengage_script_tag');
    _sNode.parentNode.insertBefore(_we, _sNode);
  })(document);
</script>
</body>
</html>